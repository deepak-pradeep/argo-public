# How to run

Just run the following commands: 

terraform init
terraform apply --auto-approve


### Please changes the values in ms_setup.tf if you need 